module.exports = {
    price: 15, // 15元/月/人
    limit: 13, // 小于13人，2000/年
    minPrice: 2000 // 小于13人，2000/年
};